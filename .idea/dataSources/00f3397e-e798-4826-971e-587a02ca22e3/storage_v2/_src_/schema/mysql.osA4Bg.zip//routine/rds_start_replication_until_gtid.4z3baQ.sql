create
    definer = rdsadmin@localhost procedure rds_start_replication_until_gtid(IN gtid text)
BEGIN
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE v_called_by_user VARCHAR(352);
  DECLARE v_service_state ENUM('ON', 'OFF', 'BROKEN');
  DECLARE v_slave_parallel_workers INT;
  DECLARE sql_logging BOOLEAN;
  SELECT @@sql_log_bin, user(), version(), mysql.rds_replication_service_state() INTO sql_logging, v_called_by_user, v_mysql_version, v_service_state;
  SELECT @@slave_parallel_workers into v_slave_parallel_workers;
  IF v_service_state in ('ON'  , 'BROKEN'  )
  THEN
    
    
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Replication may already be running. Call rds_stop_replication to stop replication';
  ELSEIF v_slave_parallel_workers > 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'rds_start_replication_until_gtid is not supported for multi-threaded slaves';
  ELSEIF gtid IS NULL THEN
    
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid input: gtid cannot be NULL';
  END IF;
  
  BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN SET @@sql_log_bin=sql_logging; RESIGNAL; END;
    SET @@sql_log_bin=OFF;
    UPDATE mysql.rds_replication_status SET called_by_user = v_called_by_user, action = 'start slave until', mysql_version = v_mysql_version, replication_gtid = gtid, replication_log_file = NULL, replication_stop_point = NULL WHERE action IS NOT NULL;
    COMMIT;
    DO SLEEP(1);
    
    SET @cmd = CONCAT('START SLAVE UNTIL SQL_AFTER_GTIDS = ', QUOTE(gtid));
    PREPARE rds_start_replication_until FROM @cmd;
    EXECUTE rds_start_replication_until;
    DEALLOCATE PREPARE rds_start_replication_until;
    DO SLEEP(2);
    SELECT mysql.rds_replication_service_state() INTO v_service_state;
    IF v_service_state = 'ON'
    THEN
      INSERT INTO mysql.rds_history(called_by_user, action, mysql_version, master_gtid) VALUES(v_called_by_user, 'start slave until', v_mysql_version, gtid);
      COMMIT;
      SELECT CONCAT('Replication started until SQL_AFTER_GTIDS = ', QUOTE(gtid)) AS Message;
    else
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Slave has encountered an error. Run SHOW SLAVE STATUS\\G; to see the error.';
    end if;
    SET @@sql_log_bin=sql_logging;
  END;
END;

