create
    definer = rdsadmin@localhost procedure rds_start_replication_until(IN replication_log_file text, IN replication_stop_point bigint)
BEGIN
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE v_called_by_user VARCHAR(352);
  DECLARE v_service_state ENUM('ON', 'OFF', 'BROKEN');
  DECLARE v_slave_parallel_workers INT;
  DECLARE sql_logging BOOLEAN;
  SELECT @@sql_log_bin, user(), version(), mysql.rds_replication_service_state() INTO sql_logging, v_called_by_user, v_mysql_version, v_service_state;
  SELECT @@slave_parallel_workers into v_slave_parallel_workers;
  IF v_service_state in ('ON'  , 'BROKEN'  )
  THEN
    
    
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Replication may already be running. Call rds_stop_replication to stop replication';
  ELSEIF v_slave_parallel_workers > 1 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'rds_start_replication_until is not supported for multi-threaded slaves';
  ELSEIF replication_stop_point IS NULL OR replication_stop_point <= 0 THEN
    
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid input: replication_stop_point cannot be NULL, less than or equal to 0';
  END IF;
  
  BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN SET @@sql_log_bin=sql_logging; RESIGNAL; END;
    SET @@sql_log_bin=OFF;
    UPDATE mysql.rds_replication_status SET called_by_user = v_called_by_user, action = 'start slave until', mysql_version = v_mysql_version, replication_log_file = TRIM(replication_log_file), replication_stop_point = replication_stop_point, replication_gtid = NULL WHERE action IS NOT NULL;
    COMMIT;
    DO SLEEP(1);
    
    SET @cmd = CONCAT('START SLAVE UNTIL MASTER_LOG_FILE = ', QUOTE(TRIM(replication_log_file)), ', MASTER_LOG_POS = ', replication_stop_point);
    PREPARE rds_start_replication_until FROM @cmd;
    EXECUTE rds_start_replication_until;
    DEALLOCATE PREPARE rds_start_replication_until;
    DO SLEEP(2);
    SELECT mysql.rds_replication_service_state() INTO v_service_state;
    IF v_service_state = 'ON'
    THEN
      INSERT INTO mysql.rds_history(called_by_user, action, mysql_version, master_log_file, master_log_pos) VALUES(v_called_by_user, 'start slave until', v_mysql_version, SUBSTRING(replication_log_file, 1, 50), replication_stop_point);
      COMMIT;
      SELECT CONCAT('Replication started until MASTER_LOG_FILE = ', QUOTE(TRIM(replication_log_file)), ' and MASTER_LOG_POS = ', replication_stop_point) AS Message;
    else
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Slave has encountered an error. Run SHOW SLAVE STATUS\\G; to see the error.';
    end if;
    SET @@sql_log_bin=sql_logging;
  END;
END;

